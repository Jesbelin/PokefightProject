* Page ChoixCombattant.php:
	1- Fait:
		- mettre une pokeball au centre, entre les listes de choix du pokemon
		- la remplacer par la photo du pokemon s�lectionn�
			-> j'ai d� trifouiller un peu ton code Emerick mais promis, j'ai rien cass�, j'ai pris mes pr�cautions
et fait mes essais sur une copie TEST de ta page de script et j'ai copi� coll� dans ta page une fois que c'�tait bon

	2- Echou�:
		- faire appara�tre une bande horizontale sous les boutons de choix o� appara�traient c�te � c�te:
			� la liste des attaques du pokemon choisi
			� la force de l'attaque
			� la pr�cision de l'attaque
			� le type de l'attaque
				-> j'ai bien compris comment tu avais fait tes scripts et requ�tes Emerick mais je n'arrive pas
� en faire un qui marche par moi-m�me. Je continue d'y travailler mais si tu veux en pr�parer de ton c�t� au cas o� je revienne
les mains vides lundi, n'h�site pas. Je comprendrais si tu ne veux pas hein, tu en as d�j� fait �norm�ment.

~~~~~~~

* Page Combat.php:
	1- Fait:
		- j'ai vir� le Header de la page
		- on arrive directement sur l'ar�ne de combat (un joli coin de for�t) qui est en fait le fond du main, qui prend
tout l'�cran
		- j'ai r�ussi � positionner les barres de vie de chaque pok�mon, chacune dans un coin

	2- Echou�:
		- le tutoriel pour faire la barre lat�rale qui appara�t quand on passe dessus n'a pas march�. Ca a fait un truc d�gueu
du coup je l'ai vir� et je regarde pour un autre tuto.
		- impossible de changer la taille des barres de vie. J'ai trouv� un tuto mais il va falloir que je trifouille ton code
Emerick (j'ai d�j� essay�, sur une copie Test de ton code et �a m'a lev� plein d'erreurs,mais j'abandonne pas!).


~~~~~~~

* Normalement tout mon code CSS est bien comment�, si vous avez envie d'aller le trifouiller pour tenter des choses.

* Je vous envoie le site tel qu'il est maintenant mais �a ne veut pas dire que j'abandonne son optimisation hein! Je garde cette copie au chaud
et je tente des trucs sur une autre copie. Je voulais juste que vous l'ayiez. 

* J'ai test� le site sur 3 ordis (le mien, celui que j'ai 'r�quisition�' � la CCI et celui que j'ai r�quisitionn� d'une amie) et il marche. 
Donc bon, normalement il devrait marcher chez vous aussi hein! 

* J'ai d�couvert que Wamp chie souvent dans la colle et que pour qu'il remarche, il faut le fermer et red�marrer l'ordi (oui, c'est chiant).

* Et puis voil�. 
		