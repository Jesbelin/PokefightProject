<?php 
	include('database.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Le combat va démarrer!</title>
	<link rel="stylesheet" type="text/css" href="styleCombat.css">
</head>
<body>
	<!-- Contenaire pour l'arene -->
	<div class="mainCombat">
		<!-- Contenaire pour le rang du haut de l'arene -->
		<div class="combatHaut">
			<p class="hautGauche">
				<!-- Adversaire -->
			</p>

			<div class="pdvBarrePoke"></div> 
		</div>

		<!-- Contenaire pour le rang du haut de l'arene -->
		<div class="combatBas">

			<div class="pdvBarreAdv"></div>

			<p class="basDroite">
				<!-- Moi -->
			</p>
		</div>
	</div>

	
	<!-- Contenaire pour la barre d'attaques pour la customiser et 
	la disposer sur la largeur de l'écran -->
		<div class="pokeAttacks"></div>
			

	<footer class="footer">
		<p>
	  		<a href="Accueil.html" class="text_footer">
	  			Accueil
	  		</a>
	  	</p>

	  	<p class="footer_space">
	  		       
	  	</p>

	  	<p>
	  		<a href="ChoixCombattants.php" class="text_footer">
	  			Choix Pokemon
	  		</a>
			
	  	</p>
	</footer>
	
	<script type="text/javascript" src="scriptPageCombat.js">	
	</script>
</body>
</html>