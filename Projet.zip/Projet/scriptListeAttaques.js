let puissance = document.getElementById('PuissanceAttaque');
let precision = document.getElementById('PrecisionAttaque');
let type = document.getElementById('TypeAttaque');

function RequestProperties(str) {
  if (str=="") {
    document.getElementById("proprieteAttaque").innerHTML="";
    return;
  } 
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && (xmlhttp.status==200 || xmlhttp.status == 0)) {
      document.getElementById("proprieteAttaque").innerHTML = this.responseText;
    }
  }
  xmlhttp.open("GET","getAttacksProperties.php?assaut="+str);
  xmlhttp.send();
}

