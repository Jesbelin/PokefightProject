<?php 
	include('database.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Le combat va démarrer!</title>
	<link rel="stylesheet" type="text/css" href="styleChoixCombattant.css">
</head>
<body>
	<header class="header">
		<!-- Deux gifs de deux des starters parés au combat. -->
		<p>
			<img src="Images/Gifs/Pokemon_highfive.gif" class="gifHeaderTitle">
			<!-- <img src="Images/Gifs/bulbizarAttack.gif" class="gifHeaderTitle">
			<img src="Images/Gifs/carapuceAttack.gif" class="gifHeaderTitle"> -->
		</p>
		<!-- Un titre qui clignote, tout comme son fond. Voir le CSS pour les détails. -->
		<p class="blink">
			<img src="Images/Combat_title_2.png" class="logo">
			<img src="Images/Combat_title_2_Inverse.png" class="logoInverse">
		</p>
	</header>

	<div class="content">
		<main class="mainCombattants">
			<!-- <img src="Images/FightGround.jpg" class="mainFight"> -->
			<!-- <h1><center>Choix du pokemon et de ses attaques</center></h1> -->
			
		<fieldset>
			<div class="formfield-select">
				<div class="formfield-select--container color">
					<?php
						try
						{
							$bdd = new PDO('mysql:host=localhost;dbname=pokefight;charset=utf8', 'root', '');
						}
						catch (Exception $e)
						{
						        die('Erreur : ' . $e=getMessage());
						}
					?>
					
					<div class="combattant">
						<div class="identitePokemon">

							<!-- Liste des pokemons -->
		
							<p id="listPokemon">
								<select id="listPokemon1" onchange=" RequestRecupPokemon(this), RequestAttacks(this)">
									<optgroup label="Pokemon1">
									<?php
										$reponse = $bdd->query("SELECT * FROM pokemons");
										while ($donnees = $reponse->fetch()) {
									?>
									<?php echo $donnees['NOM_POKEMON_POK']; ?>
									<option value="<?php echo $donnees["NOM_POKEMON_POK"]; ?>"> <?php echo $donnees["NOM_POKEMON_POK"]; ?> </option>
									
									<?php
									}
									?>
									</optgroup>
								</select>
							</p>
							<div>
								<img src="Images/Pokeball.png" id="pokeImage">
							</div>
						</div>
						
						<div class="attaquesPokemon">
							<!-- Listes des attaques pour le pokemon -->

							<p>
								<select onchange="RequestAttackStats(this)">
									<optgroup label="attaque1" class="listAttacks1">
									
									</optgroup>
								</select>
							</p>

							<p>
								<select onchange="RequestAttackStats(this)">
									<optgroup label="attaque2" class="listAttacks2">
									
									</optgroup>
								</select>
							</p>

							<p>
								<select onchange="RequestAttackStats(this)">
									<optgroup label="attaque3" class="listAttacks3">
									
									</optgroup>
								</select>
							</p>

							<p>
								<select onchange="RequestAttackStats(this)">
									<optgroup label="attaque4" class="listAttacks4">
									
									</optgroup>
								</select>
							</p>
						</div>
					</div>
					<div class="boutons">
						<!-- Choix deuxieme pokemon -->
						<p>
						<button class="validPoke">Valider pokemon</button>
						</p>

					<!-- 	<p>
							<select id="listPokemon2" onchange="Request(this)">
								<optgroup label="Pokemon2">
								<?php
									$reponse = $bdd->query("SELECT * FROM pokemons");
									while ($donnees = $reponse->fetch()) {
								?>
								<?php echo $donnees['NOM_POKEMON_POK']; ?>
								<option value="<?php echo $donnees["NOM_POKEMON_POK"]; ?>"> <?php echo $donnees["NOM_POKEMON_POK"]; ?> </option>
								
								<?php
								}
								?>
								</optgroup>
							</select>
						</p> -->
						
						<p>
							<button class="lancerCombat">
								Lancer le combat
							</button>
						</p>

						
					</div>					
				</div>
			</div>
		</fieldset>
		<script src="ScriptAvance.js" type="text/javascript"></script>
		</main>
	</div>

	<footer class="footer">
	  	<p>
	  		<a href="Accueil.html" class="text_footer">
	  			Accueil
	  		</a>
	  	</p>
	  	<p>
	  		<a href="Combat.php">
	  			<img src="Images/Battle.png" alt="Que le match commence" class="icone_fight">
	  		</a>
			
	  	</p>
	</footer>
	
	<!-- Lien vers le fichier JavaScript utilisé pour créer l'animation pokeball fermée - pokeball ouverte. -->
	<script type="text/javascript" src="ScriptPokeball.js"></script>
</body>
</html>