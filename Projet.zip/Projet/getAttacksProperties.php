<?php

    try
        {
            $bdd = new PDO('mysql:host=localhost;dbname=pokefight;charset=utf8', 'root', '');
        }
        catch (Exception $e)
        {
                die('Erreur : ' . $e=getMessage());
        } 

    $assaut = $_GET['assaut'] ?? 'default';
        
    $infosAssaut = $bdd->prepare("
        SELECT ID_AT, NOM_ATTAQUE_AT, PUISSANCE_AT, PUISSANCE_AT, PRECISION_AT, TYPE_AT, GENRE_AT
        FROM attaque 
        Where NOM_ATTAQUE_AT = :assaut
        ");
    $infosAssaut->execute(array(':assaut'=>$_GET['assaut']));
    while ($infos = $infosAssaut->fetch()){
        $id = $infos['ID_AT'];
        $name = $infos['NOM_ATTAQUE_AT'];
        $power = $infos['PUISSANCE_AT'];
        $prec = $infos['PRECISION_AT'];
        $type = $infos['TYPE_AT'];
        $genre = $infos['GENRE_AT'];
    }

    $txt = "{\"id\":\"$id\",\"name\":\"$name\",\"power\":\"$power\",\"prec\":\"$prec\",\"type\":\"$type\",\"genre\":\"$genre\"}";
    echo $txt;